const axios = require("axios");


async function generate(bin){
  
  
  
}