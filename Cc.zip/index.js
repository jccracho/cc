const cc = require('./process_cc');
const tg = require('./tg');
const fs = require('fs');
const path= require("path");
tg.sendMessage('Hello Reku are you gay? ')

const express = require("express");

const app = express();


app.use((req,res) => {

  res.sendFile(path.join(__dirname,"ccgen.html"))
})



app.listen("3000")

