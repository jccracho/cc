const fs = require('fs');


function logsave(data) {
  const logs = fs.readFileSync('logs.txt', 'utf-8');
  fs.writeFileSync('logs.txt', logs + '\n\n' + data);
}

module.exports = logsave;
