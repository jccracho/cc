const fs = require("fs");


function remove(cc){
  const cards = fs.readFileSync("ccards","utf-8");
  const process_cards = cards.split("\n");

  const index = process_cards.indexOf(cc);
  process_cards.splice(index,1);
  fs.writeFileSync("ccards",process_cards.join("\n") )
}

module.exports = remove