const fs = require('fs') ;

function save(data) {

const success = fs.readFileSync('success', 'utf-8');

fs.writeFileSync('success', success + '\n\n' + data) ;

} 

module.exports = save
