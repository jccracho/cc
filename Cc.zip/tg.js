const tg = require('node-telegram-bot-api');
const token = "5437197833:AAF4eiygfze-y74JiTrNj8_4pcmlwOYbDtg";
const id = "-1001975534611";
const bot = new tg(token);


function sendMessage(msg){
	
  bot.sendMessage(id,msg)

}

module.exports.sendMessage = sendMessage;
